"use client"

import { useState } from "react"
import { Heart, Sparkles } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"

export default function LoveCalculator() {
  const [yourName, setYourName] = useState("")
  const [partnerName, setPartnerName] = useState("")
  const [result, setResult] = useState<null | {
    percentage: number
    message: string
    compatibility: string
  }>(null)
  const [calculating, setCalculating] = useState(false)
  const { toast } = useToast()

  const calculateLove = () => {
    if (!yourName || !partnerName) {
      toast({
        title: "Oops! Names are required",
        description: "Please enter both names to calculate your love compatibility",
        variant: "destructive",
      })
      return
    }

    setCalculating(true)

    // Simulate calculation with timeout
    setTimeout(() => {
      // Simple algorithm for fun (can be made more complex)
      const combinedNames = (yourName + partnerName).toLowerCase()
      let sum = 0

      for (let i = 0; i < combinedNames.length; i++) {
        sum += combinedNames.charCodeAt(i)
      }

      // Generate a "random" but deterministic percentage based on names
      const percentage = sum % 101

      // Generate message based on percentage
      let message, compatibility

      if (percentage >= 90) {
        message = "Wow! You two are meant to be together! ❤️"
        compatibility = "Perfect Match"
      } else if (percentage >= 70) {
        message = "Great chemistry! This could be something special!"
        compatibility = "Strong Connection"
      } else if (percentage >= 50) {
        message = "There's potential here. Give it time to grow!"
        compatibility = "Good Potential"
      } else if (percentage >= 30) {
        message = "Hmm, you might need to work on this relationship."
        compatibility = "Needs Work"
      } else {
        message = "Maybe you're better as friends? Or prove us wrong!"
        compatibility = "Challenging"
      }

      setResult({ percentage, message, compatibility })
      setCalculating(false)
    }, 1500)
  }

  const resetCalculator = () => {
    setResult(null)
    setYourName("")
    setPartnerName("")
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-pink-200 bg-white/80 backdrop-blur-sm">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-pink-600 flex items-center justify-center gap-2">
          <Heart className="h-5 w-5 text-red-500 fill-red-500" />
          True Love Calculator
          <Heart className="h-5 w-5 text-red-500 fill-red-500" />
        </CardTitle>
        <CardDescription>Enter your names to discover your love compatibility</CardDescription>
      </CardHeader>
      <CardContent>
        {!result ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="yourName">Your Name</Label>
              <Input
                id="yourName"
                placeholder="Enter your name"
                value={yourName}
                onChange={(e) => setYourName(e.target.value)}
                className="border-pink-200 focus:border-pink-400"
              />
            </div>
            <div className="flex items-center justify-center my-2">
              <div className="w-full h-px bg-pink-100"></div>
              <Heart className="mx-2 h-4 w-4 text-pink-400 fill-pink-400 flex-shrink-0" />
              <div className="w-full h-px bg-pink-100"></div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="partnerName">Partner's Name</Label>
              <Input
                id="partnerName"
                placeholder="Enter your partner's name"
                value={partnerName}
                onChange={(e) => setPartnerName(e.target.value)}
                className="border-pink-200 focus:border-pink-400"
              />
            </div>
          </div>
        ) : (
          <div className="py-4 text-center space-y-4">
            <div className="relative mx-auto w-40 h-40 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-pink-100 animate-pulse"></div>
              <div className="relative z-10">
                <div className="text-4xl font-bold text-pink-600">{result.percentage}%</div>
                <Progress value={result.percentage} className="w-32 h-2 mx-auto mt-2" />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-semibold text-pink-600 flex items-center justify-center gap-2">
                <Sparkles className="h-4 w-4 text-yellow-500" />
                {result.compatibility}
                <Sparkles className="h-4 w-4 text-yellow-500" />
              </h3>
              <p className="text-gray-700">{result.message}</p>
              <p className="text-sm text-pink-500 font-medium">
                {yourName} + {partnerName} = {result.compatibility}
              </p>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          onClick={result ? resetCalculator : calculateLove}
          className={`w-full ${
            !result ? "bg-pink-500 hover:bg-pink-600 text-white" : "bg-pink-100 hover:bg-pink-200 text-pink-600"
          }`}
          disabled={calculating}
        >
          {calculating ? (
            <>
              Calculating<span className="animate-pulse">...</span>
            </>
          ) : result ? (
            <>Try Again</>
          ) : (
            <>Calculate Love</>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}


import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageCircleHeart, Star, ArrowRight, Sparkles, Music, Hourglass, UserCheck } from "lucide-react"
import Link from "next/link"

const features = [
  {
    icon: <Star className="h-5 w-5 text-yellow-500" />,
    title: "Zodiac Love Match",
    description: "Discover your astrological compatibility",
    href: "/zodiac-match",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: <MessageCircleHeart className="h-5 w-5 text-pink-500" />,
    title: "AI Love Chat",
    description: "Chat with your virtual crush or partner",
    href: "/ai-love-chat",
    color: "bg-pink-100 text-pink-600",
  },
  {
    icon: <Sparkles className="h-5 w-5 text-amber-500" />,
    title: "Love Story Generator",
    description: "Create your own romantic story",
    href: "/love-story-generator",
    color: "bg-yellow-100 text-yellow-600",
  },
  {
    icon: <Hourglass className="h-5 w-5 text-purple-500" />,
    title: "Future Love Story",
    description: "See your future love story",
    href: "/future-love-story",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: <UserCheck className="h-5 w-5 text-indigo-500" />,
    title: "Secret Admirer Detector",
    description: "Find out who secretly loves you",
    href: "/secret-admirer",
    color: "bg-indigo-100 text-indigo-600",
  },
  {
    icon: <Music className="h-5 w-5 text-pink-500" />,
    title: "Love Song Recommender",
    description: "Get personalized romantic songs",
    href: "/love-song-recommender",
    color: "bg-pink-100 text-pink-600",
  },
]

export default function FeaturedTools() {
  return (
    <Card className="border-pink-200 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-pink-600 flex items-center gap-2">
          <Star className="h-5 w-5 text-yellow-500" />
          Featured Love Tools
        </CardTitle>
        <CardDescription>Explore our most popular love calculators and fun tools</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {features.map((feature, index) => (
            <Link href={feature.href} key={index} className="block group">
              <div className={`p-4 rounded-lg ${feature.color} transition-all duration-200 group-hover:shadow-md`}>
                <div className="flex items-center gap-3">
                  {feature.icon}
                  <div>
                    <h3 className="font-medium">{feature.title}</h3>
                    <p className="text-xs opacity-80">{feature.description}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
        <Link href="/tools">
          <Button variant="ghost" className="w-full mt-4 text-pink-600 hover:bg-pink-50 hover:text-pink-700">
            View All Tools <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  )
}


"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Heart,
  Sparkles,
  MessageCircleHeart,
  Zap,
  Star,
  Laugh,
  Clock,
  Flame,
  Search,
  Calendar,
  Gift,
  Music,
  Camera,
  Mic,
  Hourglass,
  Shuffle,
  UserCheck,
  Lightbulb,
} from "lucide-react"
import Link from "next/link"

// Define all tools with their metadata
const allTools = [
  {
    id: "love-calculator",
    icon: <Heart className="h-5 w-5 text-red-500" />,
    title: "True Love Calculator",
    description: "Calculate your love compatibility",
    href: "/",
    color: "bg-pink-100 text-pink-600",
    category: "popular",
  },
  {
    id: "zodiac-match",
    icon: <Star className="h-5 w-5 text-yellow-500" />,
    title: "Zodiac Love Match",
    description: "Discover your astrological compatibility",
    href: "/zodiac-match",
    color: "bg-purple-100 text-purple-600",
    category: "popular",
  },
  {
    id: "ai-love-chat",
    icon: <MessageCircleHeart className="h-5 w-5 text-pink-500" />,
    title: "AI Love Chat",
    description: "Chat with your virtual crush or partner",
    href: "/ai-love-chat",
    color: "bg-pink-100 text-pink-600",
    category: "ai",
  },
  {
    id: "fortune-teller",
    icon: <Zap className="h-5 w-5 text-amber-500" />,
    title: "Love Fortune Teller",
    description: "Get fun predictions about your love life",
    href: "/fortune-teller",
    color: "bg-amber-100 text-amber-600",
    category: "fun",
  },
  {
    id: "breakup-generator",
    icon: <Laugh className="h-5 w-5 text-green-500" />,
    title: "Breakup Excuse Generator",
    description: "Hilarious breakup reasons for fun",
    href: "/breakup-generator",
    color: "bg-green-100 text-green-600",
    category: "fun",
  },
  {
    id: "relationship-expiry",
    icon: <Clock className="h-5 w-5 text-blue-500" />,
    title: "Relationship Expiry",
    description: "How long will your love last?",
    href: "/relationship-expiry",
    color: "bg-blue-100 text-blue-600",
    category: "fun",
  },
  {
    id: "love-reality-check",
    icon: <Flame className="h-5 w-5 text-red-500" />,
    title: "Love Ki Aukaat Test",
    description: "Reality check for your love life",
    href: "/love-reality-check",
    color: "bg-red-100 text-red-600",
    category: "viral",
  },
  {
    id: "love-story-generator",
    icon: <Lightbulb className="h-5 w-5 text-yellow-500" />,
    title: "Love Story Generator",
    description: "Create your own romantic story",
    href: "/love-story-generator",
    color: "bg-yellow-100 text-yellow-600",
    category: "ai",
  },
  {
    id: "couple-nickname",
    icon: <UserCheck className="h-5 w-5 text-indigo-500" />,
    title: "Couple Nickname Generator",
    description: "Get cute couple names for you both",
    href: "/couple-nickname",
    color: "bg-indigo-100 text-indigo-600",
    category: "fun",
  },
  {
    id: "valentine-countdown",
    icon: <Calendar className="h-5 w-5 text-pink-500" />,
    title: "Valentine Countdown",
    description: "Timer till next Valentine's Day",
    href: "/valentine-countdown",
    color: "bg-pink-100 text-pink-600",
    category: "seasonal",
  },
  {
    id: "future-love-story",
    icon: <Hourglass className="h-5 w-5 text-purple-500" />,
    title: "Future Love Story Generator",
    description: "See your future love story",
    href: "/future-love-story",
    color: "bg-purple-100 text-purple-600",
    category: "ai",
  },
  {
    id: "secret-admirer",
    icon: <Sparkles className="h-5 w-5 text-teal-500" />,
    title: "Secret Admirer Detector",
    description: "Find out who secretly loves you",
    href: "/secret-admirer",
    color: "bg-teal-100 text-teal-600",
    category: "viral",
  },
  {
    id: "love-song-recommender",
    icon: <Music className="h-5 w-5 text-pink-500" />,
    title: "Love Song Recommender",
    description: "Get personalized romantic songs",
    href: "/love-song-recommender",
    color: "bg-pink-100 text-pink-600",
    category: "fun",
  },
  {
    id: "photo-love-scanner",
    icon: <Camera className="h-5 w-5 text-blue-500" />,
    title: "Photo Love Scanner",
    description: "Analyze your couple photos",
    href: "/photo-love-scanner",
    color: "bg-blue-100 text-blue-600",
    category: "ai",
  },
  {
    id: "voice-love-calculator",
    icon: <Mic className="h-5 w-5 text-red-500" />,
    title: "Voice Love Calculator",
    description: "Speak names to calculate love",
    href: "/voice-love-calculator",
    color: "bg-red-100 text-red-600",
    category: "ai",
  },
  {
    id: "love-proposal-generator",
    icon: <Gift className="h-5 w-5 text-pink-500" />,
    title: "Love Proposal Generator",
    description: "Create the perfect proposal",
    href: "/love-proposal-generator",
    color: "bg-pink-100 text-pink-600",
    category: "ai",
  },
  {
    id: "ex-tracker",
    icon: <Shuffle className="h-5 w-5 text-orange-500" />,
    title: "Ex Tracker",
    description: "Is your ex still thinking about you?",
    href: "/ex-tracker",
    color: "bg-orange-100 text-orange-600",
    category: "viral",
  },
]

// Categories for filtering
const categories = [
  { id: "all", label: "All Tools" },
  { id: "popular", label: "Popular" },
  { id: "ai", label: "AI Powered" },
  { id: "fun", label: "Fun & Games" },
  { id: "viral", label: "Viral" },
  { id: "seasonal", label: "Seasonal" },
]

export default function AllTools() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("all")

  // Filter tools based on search query and active category
  const filteredTools = allTools.filter((tool) => {
    const matchesSearch =
      tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeCategory === "all" || tool.category === activeCategory
    return matchesSearch && matchesCategory
  })

  return (
    <Card className="border-pink-200 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-pink-600 flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-yellow-500" />
          All Love Tools
        </CardTitle>
        <CardDescription>Explore our collection of love calculators and fun tools</CardDescription>

        <div className="mt-4 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tools..."
            className="pl-9 border-pink-200 focus:border-pink-400"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory} value={activeCategory}>
          <TabsList className="w-full mb-4 flex flex-wrap h-auto bg-pink-50 p-1">
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="flex-1 min-w-[100px] data-[state=active]:bg-white data-[state=active]:text-pink-600"
              >
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {filteredTools.map((tool) => (
                  <Link href={tool.href} key={tool.id} className="block group">
                    <div className={`p-4 rounded-lg ${tool.color} transition-all duration-200 group-hover:shadow-md`}>
                      <div className="flex items-center gap-3">
                        {tool.icon}
                        <div>
                          <h3 className="font-medium">{tool.title}</h3>
                          <p className="text-xs opacity-80">{tool.description}</p>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {filteredTools.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No tools found matching your search.</p>
                  <Button
                    variant="link"
                    className="mt-2 text-pink-600"
                    onClick={() => {
                      setSearchQuery("")
                      setActiveCategory("all")
                    }}
                  >
                    Clear filters
                  </Button>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}


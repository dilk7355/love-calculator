"use client"

import { useEffect, useState } from "react"
import { Heart } from "lucide-react"

type HeartProps = {
  size: number
  left: string
  animationDuration: number
  animationDelay: number
  opacity: number
  fill: boolean
}

export default function FloatingHearts() {
  const [hearts, setHearts] = useState<HeartProps[]>([])

  useEffect(() => {
    // Generate random hearts
    const newHearts = Array.from({ length: 20 }, (_, i) => ({
      size: Math.floor(Math.random() * 20) + 10, // 10-30px
      left: `${Math.random() * 100}%`,
      animationDuration: Math.random() * 15 + 10, // 10-25s
      animationDelay: Math.random() * 5,
      opacity: Math.random() * 0.5 + 0.3, // 0.3-0.8
      fill: Math.random() > 0.5,
    }))

    setHearts(newHearts)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((heart, index) => (
        <div
          key={index}
          className="absolute animate-float-heart"
          style={{
            left: heart.left,
            bottom: "-50px",
            animationDuration: `${heart.animationDuration}s`,
            animationDelay: `${heart.animationDelay}s`,
          }}
        >
          <Heart
            className={`text-red-500 ${heart.fill ? "fill-red-500" : ""}`}
            style={{
              width: `${heart.size}px`,
              height: `${heart.size}px`,
              opacity: heart.opacity,
            }}
          />
        </div>
      ))}
    </div>
  )
}


"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sparkles, UserCheck } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function SecretAdmirerPage() {
  const [name, setName] = useState("")
  const [birthdate, setBirthdate] = useState("")
  const [result, setResult] = useState<null | {
    admirerName: string
    description: string
    clue: string
  }>(null)
  const [isDetecting, setIsDetecting] = useState(false)
  const { toast } = useToast()

  // List of potential admirer names
  const maleNames = ["Rahul", "Aditya", "Arjun", "Vikram", "Rohan", "Karan", "Raj", "Amit", "Sanjay", "Nikhil"]
  const femaleNames = ["Priya", "Neha", "Anjali", "Pooja", "Meera", "Riya", "Ananya", "Divya", "Kavita", "Nisha"]

  // List of descriptions
  const descriptions = [
    "They've been noticing you from afar and admire your smile and personality.",
    "They're too shy to approach you directly, but they always find a reason to be near you.",
    "They've told their friends about you and how amazing they think you are.",
    "They've been trying to get your attention subtly for weeks now.",
    "They light up whenever you enter the room, but quickly look away when you notice.",
    "They've been gathering courage to talk to you but get nervous at the last moment.",
    "They've memorized your schedule just to catch glimpses of you during the day.",
    "They think about you constantly and wonder if you ever notice them.",
    "They've been dropping hints, hoping you'll pick up on their feelings.",
    "They've written your name in their diary surrounded by hearts.",
  ]

  // List of clues
  const clues = [
    "Look for someone who often wears blue around you.",
    "They usually sit near you in group settings.",
    "They've recently changed their hairstyle to catch your attention.",
    "They often ask your mutual friends about you.",
    "They've been liking all your social media posts lately.",
    "They always offer to help you with tasks or problems.",
    "They remember small details about you that others don't notice.",
    "They get unusually quiet or nervous when you're around.",
    "They've been trying to learn about your interests and hobbies.",
    "They find excuses to message you about random things.",
  ]

  const detectAdmirer = () => {
    if (!name) {
      toast({
        title: "Name required",
        description: "Please enter your name to detect your secret admirer",
        variant: "destructive",
      })
      return
    }

    setIsDetecting(true)

    // Simulate detection with timeout
    setTimeout(() => {
      // Generate a "random" but deterministic result based on name
      const nameSum = name.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0)

      // Determine gender of admirer (just for variety)
      const admirerGender = nameSum % 2 === 0 ? "female" : "male"
      const admirerNames = admirerGender === "female" ? femaleNames : maleNames

      // Select admirer name, description and clue based on name
      const admirerIndex = nameSum % admirerNames.length
      const descriptionIndex = (nameSum + 3) % descriptions.length
      const clueIndex = (nameSum + 7) % clues.length

      setResult({
        admirerName: admirerNames[admirerIndex],
        description: descriptions[descriptionIndex],
        clue: clues[clueIndex],
      })

      setIsDetecting(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-teal-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-teal-600 mb-6 text-center">Secret Admirer Detector</h1>

        <Card className="max-w-md mx-auto border-teal-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-teal-600 flex items-center justify-center gap-2">
              <UserCheck className="h-5 w-5 text-teal-500" />
              Secret Admirer Detector
            </CardTitle>
            <CardDescription>Find out who secretly has feelings for you</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="border-teal-200 focus:border-teal-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthdate">Your Birthdate (Optional)</Label>
                  <Input
                    id="birthdate"
                    type="date"
                    value={birthdate}
                    onChange={(e) => setBirthdate(e.target.value)}
                    className="border-teal-200 focus:border-teal-400"
                  />
                </div>
              </div>
            ) : (
              <div className="py-6 text-center space-y-4">
                <div className="relative mx-auto w-24 h-24 flex items-center justify-center mb-4">
                  <div className="absolute inset-0 rounded-full bg-teal-100 animate-pulse"></div>
                  <Sparkles className="relative z-10 h-12 w-12 text-teal-500" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-teal-600">Your Secret Admirer is...</h3>
                  <p className="text-2xl font-bold text-pink-600">{result.admirerName}</p>
                  <div className="bg-teal-50 p-4 rounded-lg border border-teal-200 text-left">
                    <p className="text-teal-800 mb-3">{result.description}</p>
                    <p className="text-sm font-medium text-teal-700">
                      <span className="font-bold">Clue to spot them:</span> {result.clue}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={result ? () => setResult(null) : detectAdmirer}
              className={`w-full ${
                !result ? "bg-teal-500 hover:bg-teal-600 text-white" : "bg-teal-100 hover:bg-teal-200 text-teal-600"
              }`}
              disabled={isDetecting}
            >
              {isDetecting ? (
                <>
                  Detecting admirers<span className="animate-pulse">...</span>
                </>
              ) : result ? (
                <>Detect Another Admirer</>
              ) : (
                <>Reveal My Secret Admirer</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


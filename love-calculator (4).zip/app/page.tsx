import { Suspense } from "react"
import LoveCalculator from "@/components/love-calculator"
import FeaturedTools from "@/components/featured-tools"
import HeroSection from "@/components/hero-section"
import FloatingHearts from "@/components/floating-hearts"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <HeroSection />
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            <div className="order-2 md:order-1">
              <Suspense fallback={<div className="h-[400px] rounded-xl bg-pink-100/50 animate-pulse"></div>}>
                <FeaturedTools />
              </Suspense>
            </div>
            <div className="order-1 md:order-2">
              <LoveCalculator />
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


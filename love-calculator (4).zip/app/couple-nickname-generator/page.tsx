"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { UserCheck, Copy, RefreshCw } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function CoupleNicknameGeneratorPage() {
  const [name1, setName1] = useState("")
  const [name2, setName2] = useState("")
  const [nicknames, setNicknames] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const generateNicknames = () => {
    if (!name1 || !name2) {
      toast({
        title: "Names required",
        description: "Please enter both names to generate couple nicknames",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setTimeout(() => {
      // Generate nicknames based on the names
      const newNicknames = []

      // 1. Name combinations
      const firstHalf1 = name1.substring(0, Math.ceil(name1.length / 2))
      const firstHalf2 = name2.substring(0, Math.ceil(name2.length / 2))
      const secondHalf1 = name1.substring(Math.floor(name1.length / 2))
      const secondHalf2 = name2.substring(Math.floor(name2.length / 2))

      newNicknames.push(`${firstHalf1}${secondHalf2}`)
      newNicknames.push(`${firstHalf2}${secondHalf1}`)

      // 2. Classic couple names
      newNicknames.push(`${name1} & ${name2}`)

      // 3. First letters combined
      const initial1 = name1.charAt(0).toUpperCase()
      const initial2 = name2.charAt(0).toUpperCase()
      newNicknames.push(`${initial1}${initial2} Couple`)
      newNicknames.push(`Team ${initial1}${initial2}`)

      // 4. Cute themed nicknames
      const cuteNames = [
        `${name1} Bear & ${name2} Bear`,
        `${name1} Honey & ${name2} Bunny`,
        `King ${name1} & Queen ${name2}`,
        `Mr. & Mrs. ${name1.charAt(0)}${name2.charAt(0)}`,
        `The ${name1.charAt(0)}${name2.charAt(0)} Lovebirds`,
      ]

      newNicknames.push(...cuteNames)

      setNicknames(newNicknames)
      setIsGenerating(false)
    }, 1500)
  }

  const regenerateNicknames = () => {
    generateNicknames()
  }

  const copyToClipboard = (nickname: string) => {
    navigator.clipboard.writeText(nickname)
    toast({
      title: "Copied!",
      description: `"${nickname}" copied to clipboard`,
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-indigo-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-indigo-600 mb-6 text-center">Couple Nickname Generator</h1>

        <Card className="max-w-md mx-auto border-indigo-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-indigo-600 flex items-center justify-center gap-2">
              <UserCheck className="h-5 w-5 text-indigo-500" />
              Couple Nickname Generator
            </CardTitle>
            <CardDescription>Create cute couple names for you and your partner</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {nicknames.length === 0 ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name1">First Person's Name</Label>
                      <Input
                        id="name1"
                        placeholder="Enter first name"
                        value={name1}
                        onChange={(e) => setName1(e.target.value)}
                        className="border-indigo-200 focus:border-indigo-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="name2">Second Person's Name</Label>
                      <Input
                        id="name2"
                        placeholder="Enter second name"
                        value={name2}
                        onChange={(e) => setName2(e.target.value)}
                        className="border-indigo-200 focus:border-indigo-400"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium text-indigo-600">Your Couple Nicknames</h3>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={regenerateNicknames}
                      className="flex items-center gap-1 border-indigo-200 text-indigo-600"
                    >
                      <RefreshCw className="h-3 w-3" />
                      Refresh
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {nicknames.map((nickname, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center bg-indigo-50 p-3 rounded-lg border border-indigo-200"
                      >
                        <span className="text-indigo-700">{nickname}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(nickname)}
                          className="text-indigo-500 hover:text-indigo-700 hover:bg-indigo-100"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            {nicknames.length === 0 ? (
              <Button
                onClick={generateNicknames}
                className="w-full bg-indigo-500 hover:bg-indigo-600 text-white"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    Generating nicknames<span className="animate-pulse">...</span>
                  </>
                ) : (
                  <>Generate Couple Nicknames</>
                )}
              </Button>
            ) : (
              <Button
                onClick={() => setNicknames([])}
                className="w-full bg-indigo-100 hover:bg-indigo-200 text-indigo-600"
              >
                Create New Nicknames
              </Button>
            )}
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


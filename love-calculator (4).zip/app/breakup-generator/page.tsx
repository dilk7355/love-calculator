"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Laugh, Copy } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function BreakupGeneratorPage() {
  const [name, setName] = useState("")
  const [style, setStyle] = useState("funny")
  const [excuse, setExcuse] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  // Breakup excuse templates by style
  const excuseTemplates = {
    funny: [
      "I need to break up because my pet goldfish is jealous of our relationship and has threatened to learn how to use the toilet if I don't end things with you.",
      "I'm sorry, {name}, but I've just discovered I'm allergic to people who are too perfect. My doctor says I need to date someone with more flaws for my health.",
      "I have to end our relationship because I've been secretly training to become a professional bubble wrap popper, and I need complete silence to hear those satisfying pops.",
      "I'm breaking up with you because my fortune teller said if we stay together, we'll accidentally invent a time machine and mess up the space-time continuum.",
      "I can't continue dating you, {name}, because my horoscope said I need to avoid people whose names contain vowels this year.",
    ],
    absurd: [
      "I need to break up because I've been recruited by aliens to be their Earth correspondent, and they have a strict 'no relationships' policy.",
      "I'm sorry, {name}, but I've decided to identify as a cactus, and as you know, cacti are solitary plants that don't do well in relationships.",
      "I have to end things because I'm entering a witness protection program for people who have seen their neighbors dancing in their underwear.",
      "I'm breaking up with you because I'm training my left eyebrow to become independent from my right one, and it requires all my concentration.",
      "I can't be with you anymore, {name}, because I've made a solemn vow to only date people who can recite the periodic table backwards while standing on one foot.",
    ],
    supernatural: [
      "I need to break up because my psychic revealed that in a past life, you were a pirate who stole my treasure chest, and I'm still holding a grudge.",
      "I'm sorry, {name}, but a ghost has been following me and says they'll haunt my bathroom forever if I don't end our relationship.",
      "I have to end things because I've discovered I'm part werewolf, and my wolf side has different dating preferences.",
      "I'm breaking up with you because my tarot cards showed that if we stay together, we'll accidentally summon a demon during our next dinner date.",
      "I can't continue our relationship, {name}, because a time traveler from the future told me we need to break up to prevent the zombie apocalypse.",
    ],
    celebrity: [
      "I need to break up because I've been secretly selected for the next season of 'The Bachelor/Bachelorette' and my contract forbids outside relationships.",
      "I'm sorry, {name}, but I just got a DM from a celebrity who wants to date me, and it would be rude to turn them down.",
      "I have to end things because I'm about to become famous for inventing a new dance move, and my agent says I need to be single for my public image.",
      "I'm breaking up with you because I've been cast in a reality show about single people who collect unusual lint, and they don't allow participants to be in relationships.",
      "I can't be with you anymore, {name}, because I'm writing an autobiography about my dating disasters, and I need more material for the final chapter.",
    ],
    food: [
      "I need to break up because I've decided to enter a committed relationship with pizza, and I can't handle two relationships at once.",
      "I'm sorry, {name}, but my nutritionist said I need to cut you out of my diet because you're too sweet and it's affecting my health.",
      "I have to end things because I've joined a cult that worships avocados, and they forbid dating anyone who has ever eaten guacamole.",
      "I'm breaking up with you because I've discovered that your astrological sign is incompatible with my favorite ice cream flavor.",
      "I can't continue our relationship, {name}, because I've made a solemn vow to only date people who can tell the difference between 57 types of pasta.",
    ],
  }

  const generateExcuse = () => {
    if (!name) {
      toast({
        title: "Name required",
        description: "Please enter a name to generate a breakup excuse",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setTimeout(() => {
      // Select a random excuse from the chosen style
      const templates = excuseTemplates[style as keyof typeof excuseTemplates]
      const randomTemplate = templates[Math.floor(Math.random() * templates.length)]

      // Fill in the template with the provided name
      const generatedExcuse = randomTemplate.replace(/{name}/g, name)

      setExcuse(generatedExcuse)
      setIsGenerating(false)
    }, 1000)
  }

  const copyToClipboard = () => {
    if (excuse) {
      navigator.clipboard.writeText(excuse)
      toast({
        title: "Copied to clipboard!",
        description: "Your breakup excuse has been copied to your clipboard.",
      })
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-green-200 to-blue-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-green-600 mb-6 text-center">Breakup Excuse Generator</h1>

        <Card className="max-w-md mx-auto border-green-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-green-600 flex items-center justify-center gap-2">
              <Laugh className="h-5 w-5 text-green-500" />
              Breakup Excuse Generator
            </CardTitle>
            <CardDescription>Hilarious breakup reasons for fun (use at your own risk!)</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {!excuse ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="name">Their Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter their name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="border-green-200 focus:border-green-400"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="style">Excuse Style</Label>
                    <Select value={style} onValueChange={setStyle}>
                      <SelectTrigger id="style" className="border-green-200 focus:border-green-400">
                        <SelectValue placeholder="Choose a style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="funny">Funny</SelectItem>
                        <SelectItem value="absurd">Absurd</SelectItem>
                        <SelectItem value="supernatural">Supernatural</SelectItem>
                        <SelectItem value="celebrity">Celebrity</SelectItem>
                        <SelectItem value="food">Food-Related</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 p-6 rounded-lg border border-green-200 relative">
                    <p className="text-gray-800">{excuse}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={copyToClipboard}
                      className="absolute top-2 right-2 text-green-500 hover:text-green-700 hover:bg-green-100"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="text-center text-sm text-gray-500">
                    <p>⚠️ For entertainment purposes only! We don't recommend actually using these excuses! ⚠️</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={excuse ? () => setExcuse(null) : generateExcuse}
              className={`w-full ${
                !excuse
                  ? "bg-green-500 hover:bg-green-600 text-white"
                  : "bg-green-100 hover:bg-green-200 text-green-600"
              }`}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  Generating excuse<span className="animate-pulse">...</span>
                </>
              ) : excuse ? (
                <>Generate Another Excuse</>
              ) : (
                <>Generate Breakup Excuse</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


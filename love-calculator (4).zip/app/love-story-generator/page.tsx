"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lightbulb, Sparkles } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function LoveStoryGeneratorPage() {
  const [name1, setName1] = useState("")
  const [name2, setName2] = useState("")
  const [theme, setTheme] = useState("")
  const [story, setStory] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const storyTemplates = [
    `Once upon a time, in a bustling city, {name1} and {name2} crossed paths at a {theme}. Their eyes met, and time seemed to stand still. {name1} was immediately drawn to {name2}'s warm smile and kind eyes. 

After gathering courage, {name1} approached {name2} and struck up a conversation. They discovered they shared a passion for {theme}. As days turned into weeks, they found themselves spending more time together, exploring the city, and creating memories.

Their love blossomed like a beautiful flower, growing stronger with each passing day. Through challenges and triumphs, they stood by each other, their bond unbreakable. 

And as they watched the sunset on their favorite spot, {name1} knew that with {name2}, they had found their forever person. Their love story was just beginning, but it was already the most beautiful story ever told.`,

    `It was a rainy evening at the {theme} when {name1} first noticed {name2}. Seeking shelter from the downpour, they both ended up under the same awning, strangers brought together by chance.

{name1} offered to share their umbrella, and {name2} gratefully accepted. As they walked and talked, they discovered a connection that felt like they had known each other for years.

Days turned into weeks, and their chance encounter blossomed into something beautiful. They found joy in simple moments - cooking dinner together, late-night conversations, and quiet walks in the park.

Through life's storms, they became each other's shelter. {name1} and {name2}'s love story wasn't about grand gestures, but about finding home in each other's hearts.`,

    `{name1} had always been passionate about {theme}, spending countless hours perfecting their craft. Little did they know that across town, {name2} shared the same passion.

When a {theme} competition brought them together as competitors, sparks flew - both of rivalry and attraction. Their competitive spirit pushed them to excel, but also drew them closer.

After the competition ended, they decided to collaborate instead of compete. Working side by side, their admiration for each other's talents grew into something deeper.

{name1} and {name2} proved that sometimes, the greatest love stories begin as rivalries. Their shared passion had brought them together, but it was their hearts that decided to stay.`,
  ]

  const generateStory = () => {
    if (!name1 || !name2) {
      toast({
        title: "Names required",
        description: "Please enter both names to generate a love story",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setTimeout(() => {
      // Select a random story template
      const randomTemplate = storyTemplates[Math.floor(Math.random() * storyTemplates.length)]

      // Fill in the template with the provided names and theme
      const themeToUse = theme || "local café"
      const generatedStory = randomTemplate
        .replace(/{name1}/g, name1)
        .replace(/{name2}/g, name2)
        .replace(/{theme}/g, themeToUse)

      setStory(generatedStory)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-yellow-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-yellow-600 mb-6 text-center">Love Story Generator</h1>

        <Card className="max-w-2xl mx-auto border-yellow-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-yellow-600 flex items-center justify-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-500" />
              Create Your Love Story
            </CardTitle>
            <CardDescription>Generate a beautiful love story featuring you and your partner</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {!story ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name1">First Person's Name</Label>
                      <Input
                        id="name1"
                        placeholder="Enter first name"
                        value={name1}
                        onChange={(e) => setName1(e.target.value)}
                        className="border-yellow-200 focus:border-yellow-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="name2">Second Person's Name</Label>
                      <Input
                        id="name2"
                        placeholder="Enter second name"
                        value={name2}
                        onChange={(e) => setName2(e.target.value)}
                        className="border-yellow-200 focus:border-yellow-400"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="theme">Theme or Setting (Optional)</Label>
                    <Input
                      id="theme"
                      placeholder="e.g., beach, coffee shop, concert"
                      value={theme}
                      onChange={(e) => setTheme(e.target.value)}
                      className="border-yellow-200 focus:border-yellow-400"
                    />
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-center mb-4">
                    <Sparkles className="h-8 w-8 text-yellow-500" />
                  </div>
                  <div className="bg-yellow-50 p-6 rounded-lg border border-yellow-200">
                    <h3 className="text-xl font-medium text-yellow-700 mb-4 text-center">
                      The Story of {name1} & {name2}
                    </h3>
                    <div className="prose prose-yellow max-w-none">
                      {story.split("\n\n").map((paragraph, index) => (
                        <p key={index} className="mb-4">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={story ? () => setStory(null) : generateStory}
              className={`w-full ${
                !story
                  ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                  : "bg-yellow-100 hover:bg-yellow-200 text-yellow-600"
              }`}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  Writing your story<span className="animate-pulse">...</span>
                </>
              ) : story ? (
                <>Create Another Story</>
              ) : (
                <>Generate Love Story</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


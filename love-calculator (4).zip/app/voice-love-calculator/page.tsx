"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mic, Heart, StopCircle } from "lucide-react"
import SiteHeader from "@/components/site-header"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function VoiceLoveCalculatorPage() {
  const [yourName, setYourName] = useState("")
  const [partnerName, setPartnerName] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [recordingFor, setRecordingFor] = useState<"your" | "partner" | null>(null)
  const [result, setResult] = useState<null | {
    percentage: number
    message: string
  }>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const { toast } = useToast()

  const startRecording = (for_: "your" | "partner") => {
    // In a real implementation, we would use the Web Speech API here
    // For this demo, we'll simulate recording and just set the name after a delay
    setIsRecording(true)
    setRecordingFor(for_)
    
    // Simulate recording for 2 seconds
    setTimeout(() => {
      setIsRecording(false)
      setRecordingFor(null)
      
      // Generate a random name for demo purposes
      const randomNames = {
        your: ["Alex", "Jordan", "Taylor", "Sam", "Riley"],
        partner: ["Morgan", "Casey", "Jamie", "Avery", "Quinn"]
      }
      
      const randomName = randomNames[for_][Math.floor(Math.random() * 5)]
      
      if (for_ === "your") {
        setYourName(randomName)
      } else {
        setPartnerName(randomName)
      }
      
      toast({
        title: "Voice recognized",
        description: `We heard the name "${randomName}"`,
      })
    }, 2000)
  }

  const stopRecording = () => {
    setIsRecording(false)
    setRecordingFor(null)
  }

  const calculateLove = () => {
    if (!yourName || !partnerName) {
      toast({
        title: "Names required",
        description: "Please enter or speak both names to calculate compatibility",
        variant: "destructive",
      })
      return
    }

    setIsCalculating(true)

    // Simulate calculation with timeout
    setTimeout(() => {
      // Simple algorithm for fun
      const combinedNames = (yourName + partnerName).toLowerCase()
      let sum = 0

      for (let i = 0; i < combinedNames.length; i++) {
        sum += combinedNames.charCodeAt(i)
      }

      // Generate a "random" but deterministic percentage based on names
      const percentage = sum % 101

      // Generate message based on percentage
      let message
      if (percentage >= 80) {
        message = "Your voices harmonize beautifully! This is a match made in heaven!"
      } else if (percentage >= 60) {
        message = "Your vocal frequencies complement each other well. There's definite potential here!"
      } else if (percentage >= 40) {
        message = "There's some harmony between your voices, but you might need to work on communication."
      } else {
        message = "Your vocal patterns are quite different. Perhaps you balance each other out?"
      }

      setResult({ percentage, message })
      setIsCalculating(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-red-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-red-600 mb-6 text-center">Voice Love Calculator</h1>

        <Card className="max-w-md mx-auto border-red-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-red-600 flex items-center justify-center gap-2">
              <Mic className="h-5 w-5 text-red-500" />
              Voice Love Calculator
            </CardTitle>
            <CardDescription>Speak your names to calculate your love compatibility</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="yourName">Your Name</Label>
                  <div className="flex gap-2">
                    <Input
                      id="yourName"
                      placeholder="Enter or speak your name"
                      value={yourName}
                      onChange={(e) => setYourName(e.target.value)}
                      className="border-red-200 focus:border-red-400"
                    />
                    <Button
                      size="icon"
                      variant={isRecording && recordingFor === "your" ? "destructive" : "outline"}
                      className="border-red-200"
                      onClick={() => isRecording ? stopRecording() : startRecording("your")}
                    >
                      {isRecording && recordingFor === "your" ? (
                        <StopCircle className="h-4 w-4" />
                      ) : (
                        <Mic className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-center my-2">
                  <div className="w-full h-px bg-red-100"></div>
                  <Heart className="mx-2 h-4 w-4 text-red-400 fill-red-400 flex-shrink-0" />
                  <div className="w-full h-px bg-red-100"></div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="partnerName">Partner's Name</Label>
                  <div className="flex gap-2">
                    <Input
                      id="partnerName"
                      placeholder="Enter or speak partner's name"
                      value={partnerName}
                      onChange={(e) => setPartnerName(e.target.value)}
                      className="border-red-200 focus:border-red-400"
                    />
                    <Button
                      size="icon"
                      variant={isRecording && recordingFor === "partner" ? "destructive" : "outline"}
                      className="border-red-200"
                      onClick={() => isRecording ? stopRecording() : startRecording("partner")}
                    >
                      {isRecording && recordingFor === "partner" ? (
                        <StopCircle className="h-4 w-4" />
                      ) : (
                        <Mic className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-4 text-center space-y-4">
                <div className="relative mx-auto w-40\


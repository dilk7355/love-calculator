import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Mail, MapPin } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import FloatingHearts from "@/components/floating-hearts"

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-pink-300 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-pink-600">Contact Us</CardTitle>
          </CardHeader>
          <CardContent className="prose prose-pink max-w-none">
            <p>
              If you have any questions or concerns about the privacy policy or terms of service, please contact us at:
            </p>

            <div className="flex items-center gap-2 my-4">
              <Mail className="h-5 w-5 text-pink-500" />
              <span>Email: contact@truelovecalculator.fun</span>
            </div>

            <div className="flex items-center gap-2 my-4">
              <MapPin className="h-5 w-5 text-pink-500" />
              <span>Website: truelovecalculator.fun</span>
            </div>

            <p className="mt-4">We aim to respond to all inquiries promptly.</p>

            <div className="mt-8 bg-pink-50 p-6 rounded-lg border border-pink-200">
              <h3 className="text-xl font-medium text-pink-600 mb-4">Send us a message</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Your Name</Label>
                    <Input id="name" placeholder="Enter your name" className="border-pink-200 focus:border-pink-400" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Your Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      className="border-pink-200 focus:border-pink-400"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" placeholder="Enter subject" className="border-pink-200 focus:border-pink-400" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Type your message here..."
                    className="min-h-[120px] border-pink-200 focus:border-pink-400"
                  />
                </div>
                <Button className="bg-pink-500 hover:bg-pink-600 text-white">Send Message</Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
    </div>
  )
}


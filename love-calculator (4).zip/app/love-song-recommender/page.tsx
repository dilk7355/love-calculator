"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Music, Heart } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

type Song = {
  title: string
  artist: string
  year: string
  mood: string
}

export default function LoveSongRecommenderPage() {
  const [name, setName] = useState("")
  const [mood, setMood] = useState("")
  const [songs, setSongs] = useState<Song[] | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  // Song database
  const songDatabase: Song[] = [
    { title: "Perfect", artist: "Ed Sheeran", year: "2017", mood: "romantic" },
    { title: "All of Me", artist: "John Legend", year: "2013", mood: "romantic" },
    { title: "Can't Help Falling in Love", artist: "Elvis Presley", year: "1961", mood: "romantic" },
    { title: "Thinking Out Loud", artist: "Ed Sheeran", year: "2014", mood: "romantic" },
    { title: "At Last", artist: "Etta James", year: "1960", mood: "romantic" },

    { title: "I Will Always Love You", artist: "Whitney Houston", year: "1992", mood: "emotional" },
    { title: "My Heart Will Go On", artist: "Celine Dion", year: "1997", mood: "emotional" },
    { title: "Unchained Melody", artist: "Righteous Brothers", year: "1965", mood: "emotional" },
    { title: "Nothing Compares 2 U", artist: "Sinead O'Connor", year: "1990", mood: "emotional" },
    { title: "Adore You", artist: "Harry Styles", year: "2019", mood: "emotional" },

    { title: "Uptown Funk", artist: "Mark Ronson ft. Bruno Mars", year: "2014", mood: "fun" },
    { title: "Sugar", artist: "Maroon 5", year: "2015", mood: "fun" },
    { title: "Can't Stop the Feeling!", artist: "Justin Timberlake", year: "2016", mood: "fun" },
    { title: "Love On Top", artist: "Beyoncé", year: "2011", mood: "fun" },
    { title: "I Wanna Dance with Somebody", artist: "Whitney Houston", year: "1987", mood: "fun" },

    { title: "Careless Whisper", artist: "George Michael", year: "1984", mood: "sensual" },
    { title: "Earned It", artist: "The Weeknd", year: "2015", mood: "sensual" },
    { title: "Pillowtalk", artist: "Zayn", year: "2016", mood: "sensual" },
    { title: "Love to Love You Baby", artist: "Donna Summer", year: "1975", mood: "sensual" },
    { title: "Wicked Game", artist: "Chris Isaak", year: "1989", mood: "sensual" },

    { title: "Someone Like You", artist: "Adele", year: "2011", mood: "heartbreak" },
    { title: "We Are Never Ever Getting Back Together", artist: "Taylor Swift", year: "2012", mood: "heartbreak" },
    { title: "Irreplaceable", artist: "Beyoncé", year: "2006", mood: "heartbreak" },
    { title: "Since U Been Gone", artist: "Kelly Clarkson", year: "2004", mood: "heartbreak" },
    { title: "It's Too Late", artist: "Carole King", year: "1971", mood: "heartbreak" },
  ]

  const generateRecommendations = () => {
    if (!name) {
      toast({
        title: "Name required",
        description: "Please enter your name to get song recommendations",
        variant: "destructive",
      })
      return
    }

    if (!mood) {
      toast({
        title: "Mood required",
        description: "Please select a mood for your love songs",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    // Simulate API call with timeout
    setTimeout(() => {
      // Filter songs by selected mood
      const moodSongs = songDatabase.filter((song) => song.mood === mood)

      // If we have a name, use it to "personalize" the selection (just for fun)
      const nameSum = name.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0)

      // Select 3 songs from the filtered list
      const selectedSongs: Song[] = []
      for (let i = 0; i < 3 && moodSongs.length > 0; i++) {
        const index = (nameSum + i) % moodSongs.length
        selectedSongs.push(moodSongs[index])
        // Remove the selected song to avoid duplicates
        moodSongs.splice(index, 1)
      }

      setSongs(selectedSongs)
      setIsGenerating(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-purple-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">Love Song Recommender</h1>

        <Card className="max-w-md mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-pink-600 flex items-center justify-center gap-2">
              <Music className="h-5 w-5 text-pink-500" />
              Love Song Recommender
            </CardTitle>
            <CardDescription>Get personalized romantic songs based on your mood</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {!songs ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="name">Your Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="border-pink-200 focus:border-pink-400"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mood">Select Mood</Label>
                    <Select value={mood} onValueChange={setMood}>
                      <SelectTrigger id="mood" className="border-pink-200 focus:border-pink-400">
                        <SelectValue placeholder="Choose a mood" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="romantic">Romantic</SelectItem>
                        <SelectItem value="emotional">Emotional</SelectItem>
                        <SelectItem value="fun">Fun & Upbeat</SelectItem>
                        <SelectItem value="sensual">Sensual</SelectItem>
                        <SelectItem value="heartbreak">Heartbreak</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-pink-600 text-center">Your Personalized Love Songs</h3>
                  <div className="space-y-3">
                    {songs.map((song, index) => (
                      <div key={index} className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                        <div className="flex items-start gap-3">
                          <Heart className="h-5 w-5 text-pink-500 mt-0.5" />
                          <div>
                            <h4 className="font-bold text-gray-800">{song.title}</h4>
                            <p className="text-sm text-gray-600">
                              {song.artist} ({song.year})
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={songs ? () => setSongs(null) : generateRecommendations}
              className={`w-full ${
                !songs ? "bg-pink-500 hover:bg-pink-600 text-white" : "bg-pink-100 hover:bg-pink-200 text-pink-600"
              }`}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  Finding perfect songs<span className="animate-pulse">...</span>
                </>
              ) : songs ? (
                <>Get Different Songs</>
              ) : (
                <>Recommend Love Songs</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


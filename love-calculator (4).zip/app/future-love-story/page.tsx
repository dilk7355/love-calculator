"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Hourglass, Sparkles } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function FutureLoveStoryPage() {
  const [yourName, setYourName] = useState("")
  const [partnerName, setPartnerName] = useState("")
  const [years, setYears] = useState("5")
  const [story, setStory] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const { toast } = useToast()

  const futureScenarios = [
    `In {years} years, {name1} and {name2} have built a beautiful life together. They live in a cozy home with a garden where they grow their own vegetables. Every morning, they enjoy breakfast on their patio, planning their day together.

{name1} has pursued their passion for photography, while {name2} has become a respected figure in their field. They support each other's dreams and celebrate each success as if it were their own.

They've traveled to 12 countries together, collecting memories and stories from each place. Their favorite tradition is their annual trip to a new destination, where they try local foods and immerse themselves in different cultures.

Their friends often comment on how their love has only grown stronger with time. They still look at each other the way they did when they first met, with eyes full of admiration and hearts full of love.`,

    `{years} years into the future, {name1} and {name2} have become the power couple everyone admires. They've started a successful business together, combining {name1}'s creativity with {name2}'s practical skills.

Their home is filled with laughter, music, and the pitter-patter of little feet - they've adopted two rescue dogs who have become an integral part of their family. Weekends are spent hiking with their furry companions or hosting dinner parties for their close friends.

Despite their busy schedules, they always make time for each other. Their date nights are sacred - sometimes they're elaborate outings, other times they're simple evenings at home with takeout and their favorite shows.

They've weathered challenges together, emerging stronger from each one. Their secret? Communication, respect, and never going to bed angry. Their love story continues to inspire those around them.`,

    `Fast forward {years} years, and {name1} and {name2} have created a life filled with adventure and purpose. They've moved to a coastal town where they wake up to the sound of waves every morning.

{name1} has written a book about their love story, which has touched the hearts of many readers. {name2} has turned their hobby into a thriving small business that brings joy to their community.

They've learned to dance together, cook exotic meals, and speak a new language. Their home is decorated with souvenirs from their travels and photos of precious moments they've shared.

They still surprise each other with thoughtful gestures - handwritten notes, favorite treats, or spontaneous date nights. Their love has matured like fine wine, becoming richer and more complex with each passing year.`,
  ]

  const generateFutureStory = () => {
    if (!yourName || !partnerName) {
      toast({
        title: "Names required",
        description: "Please enter both names to generate your future love story",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setTimeout(() => {
      // Select a random future scenario
      const randomScenario = futureScenarios[Math.floor(Math.random() * futureScenarios.length)]

      // Fill in the template with the provided names and years
      const generatedStory = randomScenario
        .replace(/{name1}/g, yourName)
        .replace(/{name2}/g, partnerName)
        .replace(/{years}/g, years)

      setStory(generatedStory)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-purple-600 mb-6 text-center">Future Love Story Generator</h1>

        <Card className="max-w-2xl mx-auto border-purple-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-purple-600 flex items-center justify-center gap-2">
              <Hourglass className="h-5 w-5 text-purple-500" />
              See Your Future Together
            </CardTitle>
            <CardDescription>Peek into your future love story and see where your relationship leads</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              {!story ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="yourName">Your Name</Label>
                      <Input
                        id="yourName"
                        placeholder="Enter your name"
                        value={yourName}
                        onChange={(e) => setYourName(e.target.value)}
                        className="border-purple-200 focus:border-purple-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="partnerName">Partner's Name</Label>
                      <Input
                        id="partnerName"
                        placeholder="Enter partner's name"
                        value={partnerName}
                        onChange={(e) => setPartnerName(e.target.value)}
                        className="border-purple-200 focus:border-purple-400"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="years">Years into the future</Label>
                    <Input
                      id="years"
                      type="number"
                      min="1"
                      max="50"
                      placeholder="5"
                      value={years}
                      onChange={(e) => setYears(e.target.value)}
                      className="border-purple-200 focus:border-purple-400"
                    />
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-center mb-4">
                    <Sparkles className="h-8 w-8 text-purple-500" />
                  </div>
                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                    <h3 className="text-xl font-medium text-purple-700 mb-4 text-center">
                      {yourName} & {partnerName}: {years} Years Later
                    </h3>
                    <div className="prose prose-purple max-w-none">
                      {story.split("\n\n").map((paragraph, index) => (
                        <p key={index} className="mb-4">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={story ? () => setStory(null) : generateFutureStory}
              className={`w-full ${
                !story
                  ? "bg-purple-500 hover:bg-purple-600 text-white"
                  : "bg-purple-100 hover:bg-purple-200 text-purple-600"
              }`}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  Traveling to the future<span className="animate-pulse">...</span>
                </>
              ) : story ? (
                <>See Another Future</>
              ) : (
                <>Reveal Your Future</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


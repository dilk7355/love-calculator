"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shuffle, AlertTriangle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function ExTrackerPage() {
  const [exName, setExName] = useState("")
  const [yourName, setYourName] = useState("")
  const [result, setResult] = useState<null | {
    percentage: number
    thoughts: string
    advice: string
  }>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const { toast } = useToast()

  const thoughts = [
    "They think about you occasionally, especially when they see something that reminds them of you.",
    "They've mostly moved on, but your memory still brings a smile to their face.",
    "They think about you quite often and wonder how you're doing.",
    "They've been stalking your social media profiles regularly.",
    "They barely think about you anymore and are focused on their new life.",
    "They miss you deeply but are too proud to reach out.",
    "They think about you when they're feeling lonely or nostalgic.",
    "They've been comparing every new date to you.",
    "They've completely moved on and rarely think about the past.",
    "They think about you when certain songs play that remind them of your time together.",
  ]

  const advice = [
    "Focus on your own growth and happiness rather than wondering about their thoughts.",
    "The past is behind you for a reason. Look forward to new beginnings.",
    "Take this time to rediscover yourself and what makes you happy.",
    "Remember that what people show on social media isn't always their reality.",
    "It's okay to cherish the good memories while still moving forward.",
    "Don't rush into a new relationship just to fill the void.",
    "Surround yourself with positive people who support your journey.",
    "Try a new hobby or activity to create fresh experiences and memories.",
    "Allow yourself to feel your emotions, but don't let them control you.",
    "Sometimes the best closure is the kind you give yourself.",
  ]

  const analyzeEx = () => {
    if (!exName) {
      toast({
        title: "Ex's name required",
        description: "Please enter your ex's name to analyze their thoughts",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)
    setTimeout(() => {
      // Generate a "random" but deterministic result based on names
      const combinedNames = (yourName + exName).toLowerCase()
      let sum = 0

      for (let i = 0; i < combinedNames.length; i++) {
        sum += combinedNames.charCodeAt(i)
      }

      // Generate percentage of how much they think about you
      const percentage = sum % 101

      // Select thought and advice based on name
      const thoughtIndex = sum % thoughts.length
      const adviceIndex = (sum + 3) % advice.length

      setResult({
        percentage,
        thoughts: thoughts[thoughtIndex],
        advice: advice[adviceIndex],
      })

      setIsAnalyzing(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-orange-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-orange-600 mb-6 text-center">Ex Tracker</h1>

        <Card className="max-w-md mx-auto border-orange-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-orange-600 flex items-center justify-center gap-2">
              <Shuffle className="h-5 w-5 text-orange-500" />
              Ex Tracker
            </CardTitle>
            <CardDescription>Find out if your ex is still thinking about you</CardDescription>
          </CardHeader>

          <CardContent>
            {!result ? (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="exName">Ex's Name</Label>
                  <Input
                    id="exName"
                    placeholder="Enter your ex's name"
                    value={exName}
                    onChange={(e) => setExName(e.target.value)}
                    className="border-orange-200 focus:border-orange-400"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="yourName">Your Name (Optional)</Label>
                  <Input
                    id="yourName"
                    placeholder="Enter your name"
                    value={yourName}
                    onChange={(e) => setYourName(e.target.value)}
                    className="border-orange-200 focus:border-orange-400"
                  />
                </div>
              </div>
            ) : (
              <div className="py-6 space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-medium text-orange-600 mb-2">How much {exName} thinks about you:</h3>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Not at all</span>
                    <span>Obsessively</span>
                  </div>
                  <Progress value={result.percentage} className="h-2 mb-2" />
                  <p className="text-2xl font-bold text-orange-600">{result.percentage}%</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                    <p className="text-orange-800">{result.thoughts}</p>
                  </div>

                  <div className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                    <div className="flex gap-2 items-start">
                      <AlertTriangle className="h-5 w-5 text-pink-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-pink-800">Advice:</p>
                        <p className="mt-1 text-pink-700">{result.advice}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button
              onClick={result ? () => setResult(null) : analyzeEx}
              className={`w-full ${
                !result
                  ? "bg-orange-500 hover:bg-orange-600 text-white"
                  : "bg-orange-100 hover:bg-orange-200 text-orange-600"
              }`}
              disabled={isAnalyzing}
            >
              {isAnalyzing ? (
                <>
                  Analyzing<span className="animate-pulse">...</span>
                </>
              ) : result ? (
                <>Check Another Ex</>
              ) : (
                <>Analyze Ex's Thoughts</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Camera, Upload, Heart, Sparkles } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

export default function PhotoLoveScannerPage() {
  const [image, setImage] = useState<string | null>(null)
  const [result, setResult] = useState<null | {
    score: number
    chemistry: string
    insights: string[]
  }>(null)
  const [isScanning, setIsScanning] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    const reader = new FileReader()
    reader.onload = () => {
      setImage(reader.result as string)
      setResult(null)
    }
    reader.readAsDataURL(file)
  }

  const scanPhoto = () => {
    if (!image) {
      toast({
        title: "No image selected",
        description: "Please upload a photo to analyze",
        variant: "destructive",
      })
      return
    }

    setIsScanning(true)

    // Simulate scanning with timeout
    setTimeout(() => {
      // Generate random but plausible results
      const score = Math.floor(Math.random() * 41) + 60 // 60-100

      let chemistry
      if (score >= 90) chemistry = "Extraordinary"
      else if (score >= 80) chemistry = "Strong"
      else if (score >= 70) chemistry = "Good"
      else chemistry = "Moderate"

      const possibleInsights = [
        "Your body language shows strong mutual attraction.",
        "The way you look at each other indicates deep emotional connection.",
        "Your smiles appear genuine and synchronized.",
        "There's visible chemistry in how you position yourselves together.",
        "The physical proximity suggests comfort and intimacy.",
        "Your facial expressions mirror each other, showing emotional alignment.",
        "The photo captures moments of authentic connection.",
        "Your posture indicates openness and trust toward each other.",
        "The energy between you is palpable even in a still image.",
        "There's a natural flow in how you interact with each other.",
      ]

      // Select 3 random insights
      const shuffled = [...possibleInsights].sort(() => 0.5 - Math.random())
      const selectedInsights = shuffled.slice(0, 3)

      setResult({
        score,
        chemistry,
        insights: selectedInsights,
      })

      setIsScanning(false)
    }, 2500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-blue-600 mb-6 text-center">Photo Love Scanner</h1>

        <Card className="max-w-md mx-auto border-blue-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-blue-600 flex items-center justify-center gap-2">
              <Camera className="h-5 w-5 text-blue-500" />
              Photo Love Scanner
            </CardTitle>
            <CardDescription>Upload a couple photo to analyze your compatibility</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-center">
                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                {!image ? (
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="h-40 w-full border-dashed border-2 border-blue-300 bg-blue-50 hover:bg-blue-100 flex flex-col items-center justify-center gap-2"
                  >
                    <Upload className="h-8 w-8 text-blue-500" />
                    <span>Click to upload a couple photo</span>
                    <span className="text-xs text-muted-foreground">JPG, PNG, GIF up to 5MB</span>
                  </Button>
                ) : (
                  <div className="relative w-full">
                    <img
                      src={image || "/placeholder.svg"}
                      alt="Uploaded couple"
                      className="w-full h-48 object-cover rounded-md"
                    />
                    <Button
                      size="sm"
                      variant="secondary"
                      className="absolute bottom-2 right-2 bg-white/80"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      Change
                    </Button>
                  </div>
                )}
              </div>

              {result && (
                <div className="space-y-4 mt-4">
                  <div className="text-center">
                    <h3 className="text-lg font-medium text-blue-600 mb-2">Love Compatibility</h3>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="text-2xl font-bold text-blue-700">{result.score}%</span>
                      <span className="text-sm font-medium text-blue-600">({result.chemistry})</span>
                    </div>
                    <Progress value={result.score} className="h-2" />
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-700 mb-2 flex items-center gap-1">
                      <Sparkles className="h-4 w-4 text-blue-500" />
                      AI Insights
                    </h4>
                    <ul className="space-y-2">
                      {result.insights.map((insight, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <Heart className="h-4 w-4 text-pink-500 mt-0.5 flex-shrink-0" />
                          <span>{insight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <CardFooter>
            <Button
              onClick={scanPhoto}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
              disabled={!image || isScanning}
            >
              {isScanning ? (
                <>
                  <span className="animate-pulse">Scanning photo...</span>
                  <Progress value={isScanning ? 50 : 0} className="h-1 mt-1" />
                </>
              ) : (
                <>Analyze Compatibility</>
              )}
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


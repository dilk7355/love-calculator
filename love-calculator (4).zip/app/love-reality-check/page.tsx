"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Flame, AlertTriangle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import FloatingHearts from "@/components/floating-hearts"

type Question = {
  id: number
  text: string
  options: {
    value: string
    label: string
    score: number
  }[]
}

export default function LoveRealityCheckPage() {
  const [name, setName] = useState("")
  const [crushName, setCrushName] = useState("")
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [result, setResult] = useState<null | {
    score: number
    reality: string
    advice: string
  }>(null)
  const { toast } = useToast()

  const questions: Question[] = [
    {
      id: 1,
      text: "How often do you and your crush talk?",
      options: [
        { value: "daily", label: "Every day", score: 10 },
        { value: "weekly", label: "A few times a week", score: 7 },
        { value: "occasionally", label: "Occasionally", score: 4 },
        { value: "rarely", label: "Rarely or never", score: 1 },
      ],
    },
    {
      id: 2,
      text: "Does your crush initiate conversations with you?",
      options: [
        { value: "always", label: "Yes, frequently", score: 10 },
        { value: "sometimes", label: "Sometimes", score: 6 },
        { value: "rarely", label: "Rarely", score: 3 },
        { value: "never", label: "Never", score: 0 },
      ],
    },
    {
      id: 3,
      text: "How does your crush react when you're around?",
      options: [
        { value: "excited", label: "Seems happy and engaged", score: 10 },
        { value: "friendly", label: "Friendly but neutral", score: 6 },
        { value: "indifferent", label: "Seems indifferent", score: 3 },
        { value: "avoids", label: "Seems uncomfortable or avoids me", score: 0 },
      ],
    },
    {
      id: 4,
      text: "Has your crush ever shown signs of jealousy?",
      options: [
        { value: "definitely", label: "Yes, definitely", score: 8 },
        { value: "maybe", label: "Maybe, it's hard to tell", score: 5 },
        { value: "no", label: "No, never", score: 2 },
        { value: "opposite", label: "They encourage me to see other people", score: 0 },
      ],
    },
    {
      id: 5,
      text: "Do your friends think your crush likes you back?",
      options: [
        { value: "yes", label: "Yes, they're convinced", score: 8 },
        { value: "maybe", label: "Some think so, others don't", score: 5 },
        { value: "no", label: "No, they don't think so", score: 2 },
        { value: "warning", label: "They've warned me not to pursue this", score: 0 },
      ],
    },
  ]

  const handleStart = () => {
    if (!name || !crushName) {
      toast({
        title: "Names required",
        description: "Please enter both names to continue",
        variant: "destructive",
      })
      return
    }
    setCurrentStep(1)
  }

  const handleAnswer = (questionId: number, value: string) => {
    setAnswers({ ...answers, [questionId]: value })
  }

  const handleNext = () => {
    if (!answers[questions[currentStep - 1].id]) {
      toast({
        title: "Answer required",
        description: "Please select an answer to continue",
        variant: "destructive",
      })
      return
    }
    setCurrentStep(currentStep + 1)
  }

  const handlePrevious = () => {
    setCurrentStep(currentStep - 1)
  }

  const calculateResult = () => {
    if (!answers[questions[currentStep - 1].id]) {
      toast({
        title: "Answer required",
        description: "Please select an answer to continue",
        variant: "destructive",
      })
      return
    }

    // Calculate score
    let totalScore = 0
    let maxPossibleScore = 0

    questions.forEach((question) => {
      const selectedOption = question.options.find((option) => option.value === answers[question.id])
      if (selectedOption) {
        totalScore += selectedOption.score
      }

      // Find max possible score for this question
      const maxScore = Math.max(...question.options.map((option) => option.score))
      maxPossibleScore += maxScore
    })

    // Convert to percentage
    const percentageScore = Math.round((totalScore / maxPossibleScore) * 100)

    // Determine reality check and advice
    let reality, advice

    if (percentageScore >= 80) {
      reality = "There's a strong chance that your feelings are reciprocated! The signs look very positive."
      advice = "Consider having an honest conversation about your feelings. The timing seems right!"
    } else if (percentageScore >= 60) {
      reality = "There's potential here. Your crush might have some interest, but it's not completely clear yet."
      advice = "Try spending more quality time together and see if the connection deepens before making a big move."
    } else if (percentageScore >= 40) {
      reality = "The signals are mixed. Your crush might see you as a friend or they're not showing clear interest yet."
      advice = "Focus on building a stronger friendship first and watch for changes in their behavior toward you."
    } else if (percentageScore >= 20) {
      reality = "The signs suggest your crush might not share your romantic feelings right now."
      advice =
        "It might be best to manage your expectations and consider whether pursuing this is worth potential disappointment."
    } else {
      reality = "Sorry, but the reality check indicates this crush is unlikely to develop into something mutual."
      advice = "It might be time to redirect your emotional energy toward someone who shows more interest in you."
    }

    setResult({
      score: percentageScore,
      reality,
      advice,
    })

    setCurrentStep(currentStep + 1)
  }

  const resetTest = () => {
    setName("")
    setCrushName("")
    setCurrentStep(0)
    setAnswers({})
    setResult(null)
  }

  const renderStep = () => {
    if (currentStep === 0) {
      return (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Your Name</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border-red-200 focus:border-red-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="crushName">Your Crush's Name</Label>
            <Input
              id="crushName"
              placeholder="Enter your crush's name"
              value={crushName}
              onChange={(e) => setCrushName(e.target.value)}
              className="border-red-200 focus:border-red-400"
            />
          </div>
          <Button onClick={handleStart} className="w-full bg-red-500 hover:bg-red-600 text-white">
            Start Reality Check
          </Button>
        </div>
      )
    } else if (currentStep <= questions.length) {
      const question = questions[currentStep - 1]
      return (
        <div className="space-y-4">
          <div className="flex justify-between text-sm text-red-600">
            <span>
              Question {currentStep} of {questions.length}
            </span>
            <span>{Math.round((currentStep / questions.length) * 100)}% Complete</span>
          </div>
          <Progress value={(currentStep / questions.length) * 100} className="h-2" />

          <div className="py-2">
            <h3 className="text-lg font-medium text-gray-800 mb-4">{question.text}</h3>

            <RadioGroup
              value={answers[question.id] || ""}
              onValueChange={(value) => handleAnswer(question.id, value)}
              className="space-y-3"
            >
              {question.options.map((option) => (
                <div key={option.value} className="flex items-center space-x-2">
                  <RadioGroupItem
                    value={option.value}
                    id={`q${question.id}-${option.value}`}
                    className="border-red-400 text-red-600"
                  />
                  <Label htmlFor={`q${question.id}-${option.value}`} className="text-gray-700">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="flex justify-between pt-2">
            <Button
              onClick={handlePrevious}
              variant="outline"
              className="border-red-200 text-red-600"
              disabled={currentStep === 1}
            >
              Previous
            </Button>
            {currentStep < questions.length ? (
              <Button onClick={handleNext} className="bg-red-500 hover:bg-red-600 text-white">
                Next
              </Button>
            ) : (
              <Button onClick={calculateResult} className="bg-red-500 hover:bg-red-600 text-white">
                See Results
              </Button>
            )}
          </div>
        </div>
      )
    } else if (result) {
      return (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-red-600 mb-2">Love Ki Aukaat Result</h3>
            <div className="relative mx-auto w-32 h-32 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-red-100"></div>
              <div className="relative z-10">
                <div className="text-3xl font-bold text-red-600">{result.score}%</div>
                <div className="text-sm text-red-500 mt-1">Reality Score</div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <div className="flex items-start gap-2">
                <Flame className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-red-700">Reality Check:</p>
                  <p className="text-red-600 mt-1">{result.reality}</p>
                </div>
              </div>
            </div>

            <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-amber-700">Advice:</p>
                  <p className="text-amber-600 mt-1">{result.advice}</p>
                </div>
              </div>
            </div>
          </div>

          <Button onClick={resetTest} className="w-full bg-red-100 hover:bg-red-200 text-red-600">
            Take Another Test
          </Button>
        </div>
      )
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-red-200 to-pink-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-red-600 mb-6 text-center">Love Ki Aukaat Test</h1>

        <Card className="max-w-md mx-auto border-red-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-red-600 flex items-center justify-center gap-2">
              <Flame className="h-5 w-5 text-red-500" />
              Love Ki Aukaat Test
            </CardTitle>
            <CardDescription>Reality check for your love life</CardDescription>
          </CardHeader>

          <CardContent>{renderStep()}</CardContent>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}


"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Heart } from "lucide-react"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"
import { Toaster } from "@/components/ui/toaster"
import FloatingHearts from "@/components/floating-hearts"

type TimeLeft = {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export default function ValentineCountdownPage() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const [nextValentine, setNextValentine] = useState<Date>(new Date())
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Calculate the next Valentine's Day
    const calculateNextValentine = () => {
      const now = new Date()
      const currentYear = now.getFullYear()
      let valentineDate = new Date(currentYear, 1, 14) // February 14 (month is 0-indexed)

      // If Valentine's Day has already passed this year, set for next year
      if (now > valentineDate) {
        valentineDate = new Date(currentYear + 1, 1, 14)
      }

      setNextValentine(valentineDate)
      return valentineDate
    }

    const nextVal = calculateNextValentine()

    // Calculate time remaining
    const calculateTimeLeft = () => {
      const now = new Date()
      const difference = nextVal.getTime() - now.getTime()

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24))
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
        const seconds = Math.floor((difference % (1000 * 60)) / 1000)

        setTimeLeft({ days, hours, minutes, seconds })
      } else {
        // Valentine's Day is today!
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
      }

      setLoading(false)
    }

    // Initial calculation
    calculateTimeLeft()

    // Update countdown every second
    const timer = setInterval(calculateTimeLeft, 1000)

    // Cleanup interval on component unmount
    return () => clearInterval(timer)
  }, [])

  // Format date for display
  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Get love tips based on days left
  const getLoveTip = () => {
    if (timeLeft.days > 30) {
      return "Start planning something special for your loved one. It's never too early to show you care!"
    } else if (timeLeft.days > 14) {
      return "Time to start looking for the perfect gift or planning a romantic date!"
    } else if (timeLeft.days > 7) {
      return "Make reservations now if you're planning to go out. Popular places fill up quickly!"
    } else if (timeLeft.days > 1) {
      return "Almost there! Don't forget to pick up flowers, chocolates, or a heartfelt card."
    } else if (timeLeft.days === 1) {
      return "Valentine's Day is tomorrow! Make sure everything is ready for your special someone."
    } else {
      return "Happy Valentine's Day! Today is all about celebrating love and connection."
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-pink-200 to-red-200 relative overflow-hidden">
      <FloatingHearts />
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-pink-600 mb-6 text-center">Valentine's Day Countdown</h1>

        <Card className="max-w-md mx-auto border-pink-200 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-pink-600 flex items-center justify-center gap-2">
              <Calendar className="h-5 w-5 text-pink-500" />
              Valentine's Day Countdown
            </CardTitle>
            <CardDescription>Counting down to the most romantic day of the year</CardDescription>
          </CardHeader>

          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-pulse flex space-x-2">
                  <Heart className="h-6 w-6 text-pink-500 fill-pink-500" />
                  <Heart className="h-6 w-6 text-pink-500 fill-pink-500" />
                  <Heart className="h-6 w-6 text-pink-500 fill-pink-500" />
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <p className="text-lg font-medium text-pink-600 mb-2">Next Valentine's Day:</p>
                  <p className="text-xl font-bold text-red-600">{formatDate(nextValentine)}</p>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="bg-pink-100 rounded-lg p-3">
                    <div className="text-2xl md:text-3xl font-bold text-pink-600">{timeLeft.days}</div>
                    <div className="text-xs text-pink-500">Days</div>
                  </div>
                  <div className="bg-pink-100 rounded-lg p-3">
                    <div className="text-2xl md:text-3xl font-bold text-pink-600">{timeLeft.hours}</div>
                    <div className="text-xs text-pink-500">Hours</div>
                  </div>
                  <div className="bg-pink-100 rounded-lg p-3">
                    <div className="text-2xl md:text-3xl font-bold text-pink-600">{timeLeft.minutes}</div>
                    <div className="text-xs text-pink-500">Minutes</div>
                  </div>
                  <div className="bg-pink-100 rounded-lg p-3">
                    <div className="text-2xl md:text-3xl font-bold text-pink-600">{timeLeft.seconds}</div>
                    <div className="text-xs text-pink-500">Seconds</div>
                  </div>
                </div>

                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <div className="flex items-start gap-2">
                    <Heart className="h-5 w-5 text-red-500 fill-red-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-red-700">Love Tip:</p>
                      <p className="text-red-600 mt-1">{getLoveTip()}</p>
                    </div>
                  </div>
                </div>

                {timeLeft.days === 0 && timeLeft.hours === 0 && timeLeft.minutes === 0 && timeLeft.seconds === 0 && (
                  <div className="text-center py-4">
                    <div className="text-2xl font-bold text-red-600">Happy Valentine's Day! ❤️</div>
                    <p className="text-pink-600 mt-2">Today is the day to celebrate love and connection!</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      <SiteFooter />
      <Toaster />
    </div>
  )
}

